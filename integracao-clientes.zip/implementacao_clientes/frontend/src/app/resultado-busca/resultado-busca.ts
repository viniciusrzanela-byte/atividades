import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Produto } from '../model/produto';
import { ProdutoService } from '../services/produto-service';
import { ItemCesta } from '../model/item-cesta';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-resultado-busca',
  styleUrl: './resultado-busca.css',
  templateUrl: './resultado-busca.html',
})
export class ResultadoBusca {
  lista: Produto[] = [];
  mensagem:String="";
  termo:String="";

  constructor(private service:ProdutoService){}

  fazerBusca(){
    this.mensagem = "";
    this.service.pesquisar(this.termo).subscribe({
      next:(dados) =>{ //se der certo vamos realizar o proximo passo
        this.lista = dados;
        console.log(this.lista.length); 
        if(this.lista.length <=0) this.mensagem = "não foram econtrados produtos com o termo:"+ this.termo;
        else this.mensagem = "foram encontrados "+ this.lista.length + " produto(s)";
      },
      error: (err) =>{
        this.mensagem = "Ocorreu um erro, tente mais tarde!";
      }
    });

  }

  verDetalhe(obj:Produto){
    localStorage.setItem("produto", JSON.stringify(obj));  
    location.href = "detalhe";
  }

  adicionarItem(obj:Produto){
    let cesta : ItemCesta[] = [];
    let achou : boolean = false;

    let json = localStorage.getItem("cesta");
    if(json!=null) {
      cesta = JSON.parse(json);
      for(let itm of cesta){
        if(itm.produto.codigo == obj.codigo) {
            itm.quantidade++;
            itm.valorTotal = itm.valorVenda * itm.quantidade;  
            achou = true;
        }    
      }
    } 
    if(!achou) cesta.push(new ItemCesta(obj));
    
    localStorage.setItem("cesta", JSON.stringify(cesta));
    location.href="cesta";
  }

}
