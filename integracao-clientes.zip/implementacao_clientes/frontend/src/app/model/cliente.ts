export class Cliente {
    codigo:number=0;
    ativo:number=1;
    nome:string="";
    email:string="";
    telefone:string="";
    documento:string="";
    senha:string="";
    logradouro:string="";
}
