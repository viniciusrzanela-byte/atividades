import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cliente } from '../model/cliente';
import { ClienteService } from '../services/cliente-service';

@Component({
  selector: 'app-clientes',
  imports: [CommonModule],
  templateUrl: './clientes.html',
  styleUrl: './clientes.css',
})
export class Clientes implements OnInit {
  lista: Cliente[] = [];
  carregando = false;
  mensagemErro = '';

  constructor(private servico: ClienteService) {}

  ngOnInit(): void {
    this.carregarClientes();
  }

  carregarClientes(): void {
    this.carregando = true;
    this.mensagemErro = '';

    this.servico.listar().subscribe({
      next: (dados) => {
        this.lista = dados;
        this.carregando = false;
      },
      error: (erro) => {
        console.error('Erro ao carregar clientes:', erro);
        this.mensagemErro = 'Não foi possível carregar a lista de clientes. Verifique se o backend está em execução.';
        this.carregando = false;
      },
    });
  }
}
