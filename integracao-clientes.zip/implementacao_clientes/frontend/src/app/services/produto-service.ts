import { Injectable, inject } from '@angular/core';
import { Produto } from '../model/produto';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProdutoService {

    constructor(private http: HttpClient){}

    public carregarVitrine(): Observable<any> {
        return this.http.get("http://localhost:8081/api/produto/vitrine");
    }

    public gravar(obj:Produto): Observable<any> {
        return this.http.post("http://localhost:8081/api/produto", obj);
    }

    public pesquisar(termo:String): Observable<any> {
        return  this.http.get("http://localhost:8081/api/produto/busca/"+ termo);
    }

}
